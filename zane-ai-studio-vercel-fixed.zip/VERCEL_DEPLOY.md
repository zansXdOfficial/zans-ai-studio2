# Vercel deploy — fixed

The previous configuration could show 404 because it routed `/` to `/public/`.
This version lets Vercel serve `public/index.html` normally and builds only `api/index.js`.

## Steps
1. Replace the files in your GitHub repository with the contents of this ZIP.
2. In Vercel open the project → **Deployments** → **Redeploy**.
3. Make sure `OPENAI_API_KEY` exists in Vercel Environment Variables for Production/Preview.
4. Open the new deployment URL.

If you want Vercel to redeploy automatically, commit/push the changed `vercel.json`.
